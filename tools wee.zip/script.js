let pinned = JSON.parse(localStorage.getItem("pinnedTools") || "[]");

fetch("tools.json")
  .then(res => res.json())
  .then(tools => {
    const list = document.getElementById("tool-list");
    const search = document.getElementById("search");

    function render(filtered) {
      list.innerHTML = "";
      filtered.forEach(tool => {
        const isPinned = pinned.includes(tool.id);
        const card = document.createElement("div");
        card.className = "bg-white p-4 rounded shadow hover:shadow-lg transition";

        card.innerHTML = `
          <div class="flex justify-between items-start">
            <div>
              <h2 class="text-lg font-semibold">${tool.name}</h2>
              <p class="text-sm text-gray-600">${tool.description}</p>
            </div>
            <button onclick="togglePin('${tool.id}')" title="Pin this tool">
              ${isPinned ? "📌" : "📍"}
            </button>
          </div>
          <a href="${tool.url}" class="mt-3 inline-block text-blue-600 hover:underline">Open Tool →</a>
        `;
        list.appendChild(card);
      });
    }

    window.togglePin = function(id) {
      if (pinned.includes(id)) {
        pinned = pinned.filter(x => x !== id);
      } else {
        pinned.push(id);
      }
      localStorage.setItem("pinnedTools", JSON.stringify(pinned));
      render(tools.filter(t => t.name.toLowerCase().includes(search.value.toLowerCase())));
    };

    search.addEventListener("input", () => {
      const filtered = tools.filter(t => t.name.toLowerCase().includes(search.value.toLowerCase()));
      render(filtered);
    });

    render(tools);
  });
